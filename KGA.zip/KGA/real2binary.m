%{
Author: Sumaiya Iqbal, siqbal1@uno.edu, anni.are@gmail.com (Kite Genetic Algorithm)
Function for converting "real to binary" number
Input: 
r: real number to be converted to binary
d: integer part --- number of bits for decimal part of the number 
f: fraction part --- number of bits for fractional part of the number
Output:
x: output binary vector (left-most as sign bit)
--- 1st bit (left most): sign bit
--- 2 to (d+1) bits: decimal part
--- (end-f+1) to end bits: fractional part
%}

function [x] = real2binary(r, d, f)
if r > 0                    % positive weight
    x(1) = 0;               % sign bit
end
if r < 0
    x(1) = 1;              % sign bit
    r = abs(r);
end
dPart = floor(r);                                   % decimal of decimal part
dBits(1:d) = de2bi(dPart, d, 'left-msb');           % 10 bit binary of decimal part    
x(2:(d+1)) = dBits(1:d);                            % fill up 2 to 11 bits of chromosome

fPart = r - dPart;                                  % decimal of fractional part
for count_bit = 1:1:f                               % fill up 5 bits for fractional part
    fBits(count_bit) = 0;
    t = fPart * 2.0;           
    if t ~= 1.0
        fBits(count_bit) = floor(t);
        fPart = t - floor(t);
    end
    if t == 1.0
        fBits(count_bit) = floor(t);
        break;
    end
end
x((d+2):((d+2)+count_bit-1)) = fBits(1:count_bit);      % fill up 12 to 16 bits of chromosome
for fill_bit = (d+2+count_bit):1:(d+f+1)
    x(fill_bit) = 0;                                    % fill up 12 to 16 bits of chromosome
end

