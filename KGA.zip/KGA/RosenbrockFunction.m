%{
Author: Sumaiya Iqbal, Computer Science, UNO ID # 2450707
Rosenbrock test function
%}

function [fx] = RosenbrockFunction(X)

%% Input parameter checking, if input vector is empty set default
if length(X) < 2
    error('Input vector should contain atleast two (x1, x2) values');
end

N = length(X);
sum = 0;
for i = 1:(N-1)
    sumPart = 100*((X(i)^2) - X(i+1))^2 + (1 - X(i))^2;
    sum = sum + sumPart;
end
fx =  sum;                                    % function output
%%