%{
Author: Sumaiya Iqbal, siqbal1@uno.edu, anni.are@gmail.com (Kite Genetic Algorithm)
NOTES: Convert binary chromosome into real chromosome
---- Associative Memory based Crossover
---- Check subpart of only one chromosome with AM
%}

function [realChrom] = binaryChromosome2realChromosome(binaryChrom, nBeta, nBits, dBits, fBits)

%% Initialize
realChrom = zeros(1, nBeta);

%% loop for all weights/beta
temp = zeros(1, nBits);    % temporary binary for one real/weight
for k = 1: nBeta
    temp(1:nBits) = binaryChrom((((k-1)*nBits)+1):(k*nBits));
    temp_real = binary2real(temp, dBits, fBits);
    realChrom(k) = temp_real;
end

%% END