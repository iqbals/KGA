%{
Author: Sumaiya Iqbal, siqbal1@uno.edu, anni.are@gmail.com (Kite Genetic Algorithm)
NOTES: Objective Function, #variable, range, #Bits need to be changed
---- Associative Memory based Crossover
---- Includes twin removal after generation of new population
---- Single point mutation
---- Roulette wheel
---- Checking for bouds after crossover and nutation
-------- If not within range, replave with random real number and convert
            accordingly into binary
---- For initial population, generated random real values within bounds and then converted into binary 
%}

%
function [Min_Obj, Min_Obj_Epoch] = KGA(fname, dim, target)
%%------------------------------------ Initialization START%%----------------------------------------%%
%% terminating  condition 
func = str2func(fname);                     % function to be optimized
target_optima = target;
Max_Epoch = 2000;           				% one of the exit condition

Min_Obj = Inf;             					% initializing minimum objective
Min_Obj_Epoch = -1;         				% initializing epoch number to achieve minimum objective

epoch=0;                    				% initialization of epoch
optima = Inf;              					% initializing the optima (Inf for minimization and -Inf for maximization)

Obj=zeros(1, Max_Epoch);                	% For per generation objective function value
for i = 1:Max_Epoch
    Obj(i) = target_optima;
end
Epo=zeros(1, Max_Epoch);                	% For epoch

%% Rosenbrock function specific paramaters (START) --- Need to changed for other function
%% number of beta, bits and chromosome
nBeta = dim;                                % number of variables (beta / weights) %% CHANGE
VRange = [-2.048; 2.048];                   % Range of variables 
dBits = 2;                                  % decimal part 
fBits = 20;                                 % fractional part
%% Rosenbrock function specific paramaters (END)

nBits = dBits + fBits + 1;                  % number of bits (% nBits = dBits + fBits + 1)
chromL = nBeta * nBits;                     % one chromosome length
popSize = 200;                              % number of chromosome

%% GA Parameter
eRate = 0.1;                                % Elite Rate = 10%
cRate = 0.8;                                % Cross Over Rate = 80%
mRate = 0.05;                               % Mutation Rate = 70%

nE = popSize * eRate;       % number of elites    
nC = (popSize * cRate)/2;   % number of crossover
nM = popSize * mRate;       % number of mutation

%% Binary population initialization
population = round(rand(chromL, popSize));  % population of random 0 and 1
realBetaPop = ones(nBeta, popSize);         % Initialization of real valued beta population
fitness_obj = zeros(1, popSize);            % fitness matrix
pFitness = zeros(1, popSize);               % probability of fiteness 
%%------------------------------------ Initialization END%----------------------------------------%%

%%------------------------------------ Generate Initial Population Start----------------------------------------%%
%% Generate Random Real and Binary Population

for i = 1:popSize
    for j = 1: nBeta
        realBetaPop(j, i) = (VRange(2)-VRange(1)).*rand(1,1) + VRange(1);                           % real valued population
        population((((j-1)*nBits)+1):(j*nBits), i) = real2binary(realBetaPop(j, i), dBits, fBits);  % binary population
    end
end

%%------------------------------------ Generate Initial Population End----------------------------------------%%

%% SET UP FOR ASSOCIATIVE MEMORY WITH SEED
AM_row = chromL;
AM_col = chromL - 1;
AM = zeros(AM_row, AM_col); % Associated Memory

% calculate fitness of initial population
for i = 1:popSize
    fitness_obj(i) = func(realBetaPop(:, i)); % CHANGE (modified objective function to make maximization problem)
end

% Store best one to initialize AM
[~, id] = sort(fitness_obj, 'ascend');
AM_cand = population(:, id(1));
for k = 1:AM_col
    AM(:, k) = AM_cand;
end	
%% End of SET UP FOR ASSOCIATIVE MEMORY WITH SEED

%% SETUP for Twin Removal
cutoff = 1.0;						% Sequence identity cutoff is 50%
aSimilarity = ceil(chromL * cutoff);		% allowable identical bits
cutoff_limit = 0.8;
cutoff_change = 0.00015;

%% End of SETUP for Twin Removal

%tic;
%% Start evaluation
while (epoch < Max_Epoch)                   % outer loop with exit conditions
	nextGen = zeros(chromL, popSize);       % next generation initialization (binary)
    nextGenBeta = ones(nBeta, popSize);     % next generation initialization (real)
	
	%% calculate fitness of initial population
	for i = 1:popSize
        fitness_obj(i) = func(realBetaPop(:, i));       
    end
    
    %% sort 
	[sortedFitness, id] = sort(fitness_obj, 'ascend'); 
    optima = sortedFitness(1);                              
    epoch  = epoch+1;
	
	%% setup for plotting
	Epo(epoch) = epoch; 
	Obj(epoch) = optima;	
    
    fprintf('Iteration: %d ----- Optima: %f\n', epoch, optima);
    %% check with corrent best
	if optima < Min_Obj
		Min_Obj = optima;
		Min_Obj_Epoch=epoch;
        best_beta = realBetaPop(:, id(1));
    end 
    
    %% check for termination condition reached or, not
    if Min_Obj == target_optima
        fprintf('\nFinal Result\n');
        fprintf('============\n');
        fprintf('Iteration required for finding optima: %d\n', Min_Obj_Epoch);
        fprintf('Best optima: %f\n', Min_Obj);
        return;
    end
    
    %% Start preparaing new generation
	genId = 1;	
    % Preserve the Elite
	for i = 1:nE
		nextGen(:, i) = population(:, id(i));
        nextGenBeta(:, i) = realBetaPop(:, id(i));
		genId = genId + 1;
	end

	%% Cross Over
	%% Roulette Wheel
	
    totalFitness = sum(fitness_obj);
    pFitness = sortedFitness ./ totalFitness;
    pFitness = 1 - pFitness; % CHANGE (This is for minimization)
    
	%% FULL CROSSOVER START
	for i = 1:nC		
        new1 = zeros(1, chromL);
        new2 = zeros(1, chromL);
        new1_am = zeros(1, chromL);
        new2_am = zeros(1, chromL);
        newReal1 = ones(1, nBeta);
        newReal2 = ones(1, nBeta);
        new1_am = ones(1, nBeta);
        new2_am = ones(1, nBeta);

        %% Select Candidate 1
        r1 = rand(1,1);	
        j = 1;		
        while(r1 > 0) 
            r1 = r1 - pFitness(j);
            j = j + 1;
        end
        pick1 = id(j - 1);	
        cand1 = population(:, pick1)';	

        %% Select Candidate 2
        r2 = rand(1,1);
        j = 1; 
        while(r2 > 0)
            r2 = r2 - pFitness(j);
            j = j + 1;
        end
        pick2 = id(j - 1);
        cand2 = population(:, pick2)';

        %% Do Cross Over
        %% select single crossover point
        cPoint = ceil((chromL - 1) * (rand(1,1))); %% cross over point

        %% Lower half
        %% Candidate one will be as it is and pieces of candidate 2 will be compared with AM pieces
        new1 = [cand1(1 : cPoint) cand2(cPoint + 1 : chromL)];
        new1_am = [cand1(1 : cPoint) AM(cPoint + 1: chromL, cPoint)'];

        %% binary to real (new1 to new1_real)
        newReal1 = binaryChromosome2realChromosome(new1, nBeta, nBits, dBits, fBits);
        new1_am_real = binaryChromosome2realChromosome(new1_am, nBeta, nBits, dBits, fBits);

        %% Check for range
        for k = 1: nBeta
            if (newReal1(k) < VRange(1)) || (newReal1(k) > VRange(2))               % Check range consistency
                newReal1(k) = (VRange(2)-VRange(1)).*rand(1,1) + VRange(1);
                new1((((k-1)*nBits)+1):(k*nBits)) = real2binary(newReal1(k), dBits, fBits);
            end
            if (new1_am_real(k) < VRange(1)) || (new1_am_real(k) > VRange(2))               % Check range consistency
                new1_am_real(k) = (VRange(2)-VRange(1)).*rand(1,1) + VRange(1);
                new1_am((((k-1)*nBits)+1):(k*nBits)) = real2binary(new1_am_real(k), dBits, fBits);
            end
        end

        %% calculate fitness and check who is better
        new1_fitness = func(newReal1);
        new1_am_fitness = func(new1_am_real);

        if(new1_fitness < new1_am_fitness)	% original crossover is better, update AM
            % update AM
            AM(cPoint + 1: chromL, cPoint) = cand2(cPoint + 1 : chromL);
            nextGen( :, genId) = new1';
            nextGenBeta( :, genId) = newReal1';
            genId = genId + 1;
        else								% cross over with AM is better (keep AM as it is)
            nextGen( :, genId) = new1_am';
            nextGenBeta( :, genId) = new1_am_real';
            genId = genId + 1;
        end

        %% Upper half

        %% Candidate one will be as it is and pieces of candidate 2 will be compared with AM pieces
        new2 = [cand2(1 : cPoint) cand1(cPoint + 1 : chromL)];
        new2_am = [AM(1 : cPoint, cPoint)' cand1(cPoint + 1 : chromL)];

        %% binary to real (new2 to new2_real)
        newReal2 = binaryChromosome2realChromosome(new2, nBeta, nBits, dBits, fBits);
        new2_am_real = binaryChromosome2realChromosome(new2_am, nBeta, nBits, dBits, fBits);

        %% Check for range
        for k = 1: nBeta
            if (newReal2(k) < VRange(1)) || (newReal2(k) > VRange(2))               % Check range consistency
                newReal2(k) = (VRange(2)-VRange(1)).*rand(1,1) + VRange(1);
                new2((((k-1)*nBits)+1):(k*nBits)) = real2binary(newReal2(k), dBits, fBits);
            end
            if (new2_am_real(k) < VRange(1)) || (new2_am_real(k) > VRange(2))               % Check range consistency
                new2_am_real(k) = (VRange(2)-VRange(1)).*rand(1,1) + VRange(1);
                new2_am((((k-1)*nBits)+1):(k*nBits)) = real2binary(new2_am_real(k), dBits, fBits);
            end
        end

        %% calculate fitness and check who is better
        new2_fitness = func(newReal2);
        new2_am_fitness = func(new2_am_real);

        if(new2_fitness < new2_am_fitness)	% original crossover is better, update AM
            % update AM
            AM(1 : cPoint, cPoint) = cand2(1 : cPoint);
            nextGen( :, genId) = new2';
            nextGenBeta( :, genId) = newReal2';
            genId = genId + 1;
        else								% cross over with AM is better (keep AM as it is)
            nextGen( :, genId) = new2_am';
            nextGenBeta( :, genId) = new2_am_real';
            genId = genId + 1;
        end
    end
    
	%% Fill up the rest after crossover

	fllUp = (popSize - genId) + 1;
    temp_nextGen = zeros(1, nBits);
	for i = 1:fllUp
		nextGen(:, genId) = population(:, id(genId));
        for j = 1: nBeta
            temp_nextGen(1:nBits) = population((((j-1)*nBits)+1):(j*nBits), id(genId));              % temp: one beta bits
			nextGenBeta(j, genId) = binary2real(temp_nextGen, dBits, fBits);
        end
		genId = genId + 1;
	end

	%% MUTATION
	for i = 1:nM
		ranPick = ceil((popSize - nE) * rand(1,1)) + nE;    %%% Random selection of candidate for mutation    
		candM = nextGen(:, ranPick)';
        mPoint = ceil(chromL * (rand(1,1)));                %%% Muttaion point
        if candM(mPoint) == 0
            candM(mPoint) = 1;
        elseif candM(mPoint) == 1
            candM(mPoint) = 0;
        end
        
        % check whether this new chromosome is netter than current best
        mutReal = zeros(1, nBeta);
        tempM = zeros(1, nBits);
        for k = 1: nBeta
			tempM(1:nBits) = candM((((k-1)*nBits)+1):(k*nBits));
            MReal = binary2real(tempM, dBits, fBits);
            if (MReal < VRange(1)) || (MReal > VRange(2))               % Check range consistency
                MReal = (VRange(2)-VRange(1)).*rand(1,1) + VRange(1);
                candM((((k-1)*nBits)+1):(k*nBits)) = real2binary(MReal, dBits, fBits);
            end
            mutReal(k) = MReal;
        end
       
        nextGen(:, ranPick) = candM';
        nextGenBeta(:, ranPick) = mutReal';
    end

    
    %% Twin Removal
    nSimilar = 0;
    newRandom_binary = zeros(chromL, 1);
    newRandom_real = zeros(nBeta, 1);

    %% Check up for Twins and remove if any
    twin_count = 0;
    for p1=1:1:(popSize-1)											% first in pair
        for p2=(p1+1):1:popSize                                     % second in pair				
            nSimilar = length(find(nextGen(:,p1) == nextGen(:,p2)));

            %% If twins
            if nSimilar >= aSimilarity
                twin_count = twin_count + 1;
                if(func(nextGenBeta(:, p2)) < func(nextGenBeta(:, p1)))
                    nextGen(:, p1) = nextGen(:, p2);
                    nextGenBeta(:, p1) = nextGenBeta(:, p2);
                end
                newRandom_real = (VRange(2)-VRange(1)).*rand(nBeta,1) + VRange(1);
                for j = 1: nBeta
                    newRandom_binary((((j-1)*nBits)+1):(j*nBits)) = real2binary(newRandom_real(j), dBits, fBits);  % binary population
                end
                nextGen(:, p2) = newRandom_binary;
                nextGenBeta(:, p2) = newRandom_real;
            end
        end	
    end
  
    if cutoff > cutoff_limit									% increase sequence identity cutoff to 80% max	
        cutoff = cutoff - cutoff_change;						% Sequence identity cutoff 
        aSimilarity = chromL * cutoff;				% allowable identical bits
    end
    
    %% UPDATE BINARY POPULTAION WITH NEXT GENERATION
	population = nextGen; 
	realBetaPop = nextGenBeta;  % UPDATE REAL POPULTAION WITH NEXT GENERATION
end
